package com.geospatial.validation;

import java.util.List;

import com.geospatial.Exception.DistanceKMMissingException;
import com.geospatial.Exception.Latitude1MissingException;
import com.geospatial.Exception.Latitude2MissingException;
import com.geospatial.Exception.Longitude1MissingException;
import com.geospatial.Exception.Longitude2MissingException;
import com.geospatial.Exception.ReferencePointMissingException;
import com.geospatial.model.dto.requestDTO.FindAllPointDTO;
import com.geospatial.model.dto.requestDTO.LatLongDTO;
import com.geospatial.model.dto.requestDTO.ReferencePointDTO;
import com.geospatial.model.dto.requestDTO.SortDistanceDTO;

public class Validations {
	
	public static void isValidLatLon(LatLongDTO latLong) {
		
		if(latLong.getLat1()<=0)
			throw new Latitude1MissingException("Latitude1 is missing.");
		if(latLong.getLon1()<=0)
			throw new Longitude1MissingException("Longitude1 is missing.");
		if(latLong.getLat2()<=0)
			throw new Latitude2MissingException("Latitude2 is missing.");
		if(latLong.getLon2()<=0)
			throw new Longitude2MissingException("Longitude2 is missing.");
	}

	public static void isValidAllPointDTO(FindAllPointDTO findAllPointDTO) {
		
		if(findAllPointDTO.getDistanceKM()<=0)
			throw new DistanceKMMissingException("DistanceKM is missing.");
		if(findAllPointDTO.getReferencePoint()==null)
			throw new ReferencePointMissingException("Reference point is missing.");
		isValidReferencePoint(findAllPointDTO.getReferencePoint());
		if(findAllPointDTO.getArray()==null || findAllPointDTO.getArray().isEmpty())
			throw new ReferencePointMissingException("Reference points are missing.");
		List<ReferencePointDTO> referencePoints = findAllPointDTO.getArray();
		referencePoints.forEach(e->{
			if(e==null)
				throw new ReferencePointMissingException("Reference point is missing in list.");
			isValidReferencePoint(e);
		});
	}
	public static void isValidReferencePoint(ReferencePointDTO referencePoint) {
		if(referencePoint.getLatitude()<=0)
			throw new Latitude1MissingException("Reference Latitude is missing");
		if(referencePoint.getLongitude()<=0)
			throw new Longitude1MissingException("Reference Longitude is missing");
	}

	public static void isValidSortDistanceDTO(SortDistanceDTO sortDistanceDTO) {
		
		if(sortDistanceDTO.getReferencePoint()==null)
			throw new ReferencePointMissingException("Reference point is missing.");
		isValidReferencePoint(sortDistanceDTO.getReferencePoint());
		if(sortDistanceDTO.getArray()==null || sortDistanceDTO.getArray().isEmpty())
			throw new ReferencePointMissingException("Reference points are missing.");
		List<ReferencePointDTO> referencePoints = sortDistanceDTO.getArray();
		referencePoints.forEach(e->{
			if(e==null)
				throw new ReferencePointMissingException("Reference point is missing in list.");
			isValidReferencePoint(e);
		});
	}

}
