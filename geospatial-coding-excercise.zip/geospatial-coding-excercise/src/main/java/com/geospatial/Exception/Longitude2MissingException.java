package com.geospatial.Exception;

public class Longitude2MissingException extends RuntimeException{

	private static final long serialVersionUID = -7171193668383158161L;

	public Longitude2MissingException(String message){
		super(message);
	}
}
