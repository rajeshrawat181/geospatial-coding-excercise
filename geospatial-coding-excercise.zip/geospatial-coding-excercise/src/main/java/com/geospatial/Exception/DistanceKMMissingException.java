package com.geospatial.Exception;

public class DistanceKMMissingException extends RuntimeException{

	private static final long serialVersionUID = -7171193668383158161L;

	public DistanceKMMissingException(String message){
		super(message);
	}
}
