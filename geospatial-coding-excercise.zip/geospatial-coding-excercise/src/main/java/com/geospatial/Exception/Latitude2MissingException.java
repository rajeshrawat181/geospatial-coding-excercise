package com.geospatial.Exception;

public class Latitude2MissingException extends RuntimeException{

	private static final long serialVersionUID = -7171193668383158161L;

	public Latitude2MissingException(String message){
		super(message);
	}
}
