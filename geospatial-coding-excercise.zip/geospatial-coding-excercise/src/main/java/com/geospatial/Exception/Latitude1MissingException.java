package com.geospatial.Exception;

public class Latitude1MissingException extends RuntimeException{

	private static final long serialVersionUID = -7171193668383158161L;

	public Latitude1MissingException(String message){
		super(message);
	}
}
