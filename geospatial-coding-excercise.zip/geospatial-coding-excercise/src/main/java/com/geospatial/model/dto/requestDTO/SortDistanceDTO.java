package com.geospatial.model.dto.requestDTO;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class SortDistanceDTO implements Serializable{
	
	private static final long serialVersionUID = 8873000105898708984L;
	private ReferencePointDTO referencePoint;
	private List<ReferencePointDTO> array;

}
