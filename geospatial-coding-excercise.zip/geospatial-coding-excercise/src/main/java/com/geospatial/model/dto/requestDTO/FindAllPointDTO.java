package com.geospatial.model.dto.requestDTO;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class FindAllPointDTO implements Serializable{
	
	private static final long serialVersionUID = 3104353920368432610L;
	private ReferencePointDTO referencePoint;
	private double distanceKM;
	private List<ReferencePointDTO> array;

}
