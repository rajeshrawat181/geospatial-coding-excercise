package com.geospatial.model.dto.responseDTO;

import java.io.Serializable;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@Builder
public class DistanceDTO implements Serializable{

	private static final long serialVersionUID = -1126252636994930441L;
	private double distanceKM;

}
