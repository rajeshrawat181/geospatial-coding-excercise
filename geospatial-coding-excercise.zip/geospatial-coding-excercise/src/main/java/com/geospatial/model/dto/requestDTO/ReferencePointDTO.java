package com.geospatial.model.dto.requestDTO;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class ReferencePointDTO implements Serializable{

	private static final long serialVersionUID = 6971858414594265361L;
	private double latitude;
	private double longitude;

}
