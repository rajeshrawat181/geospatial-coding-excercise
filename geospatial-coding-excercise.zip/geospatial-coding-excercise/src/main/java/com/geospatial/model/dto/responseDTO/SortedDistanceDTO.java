package com.geospatial.model.dto.responseDTO;

import java.io.Serializable;
import java.util.List;

import com.geospatial.model.dto.requestDTO.ReferencePointDTO;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@Builder
public class SortedDistanceDTO implements Serializable{

	
	private static final long serialVersionUID = -7470878679646699782L;
	private List<ReferencePointDTO> sortedArray;

}
