package com.geospatial.model.dto.requestDTO;

import java.io.Serializable;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@Builder
public class LatLongDTO implements Serializable{

	private static final long serialVersionUID = -7908258132714764660L;
	private double lat1;
	private double lon1;
	private double lat2;
	private double lon2;

}
