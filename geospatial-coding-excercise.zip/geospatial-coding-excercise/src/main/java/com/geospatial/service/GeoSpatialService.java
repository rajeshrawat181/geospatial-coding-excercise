package com.geospatial.service;

import com.geospatial.model.dto.requestDTO.FindAllPointDTO;
import com.geospatial.model.dto.requestDTO.LatLongDTO;
import com.geospatial.model.dto.requestDTO.SortDistanceDTO;
import com.geospatial.model.dto.responseDTO.DistanceDTO;
import com.geospatial.model.dto.responseDTO.ResultPointDTO;
import com.geospatial.model.dto.responseDTO.SortedDistanceDTO;

public interface GeoSpatialService {
	
	public DistanceDTO calculateDistance(LatLongDTO latLong);

	public ResultPointDTO findPoints(FindAllPointDTO findAllPointDTO);

	public SortedDistanceDTO sortDistance(SortDistanceDTO sortDistanceDTO);

}
