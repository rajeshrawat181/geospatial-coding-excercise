package com.geospatial.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import org.springframework.stereotype.Service;

import com.geospatial.common.CommonFunctions;
import com.geospatial.model.dto.requestDTO.FindAllPointDTO;
import com.geospatial.model.dto.requestDTO.LatLongDTO;
import com.geospatial.model.dto.requestDTO.ReferencePointDTO;
import com.geospatial.model.dto.requestDTO.SortDistanceDTO;
import com.geospatial.model.dto.responseDTO.DistanceDTO;
import com.geospatial.model.dto.responseDTO.ResultPointDTO;
import com.geospatial.model.dto.responseDTO.SortedDistanceDTO;
import com.geospatial.service.GeoSpatialService;
import com.geospatial.validation.Validations;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GeoSpatialServiceImpl implements GeoSpatialService {

	@Override
	public DistanceDTO calculateDistance(LatLongDTO latLong) {
		Validations.isValidLatLon(latLong);
		return DistanceDTO.builder().distanceKM(CommonFunctions.getDistanceFromLatLonInKm(latLong)).build();
	}

	@Override
	public ResultPointDTO findPoints(FindAllPointDTO findAllPointDTO) {
		Validations.isValidAllPointDTO(findAllPointDTO);
		List<ReferencePointDTO> lieReferences = new ArrayList<ReferencePointDTO>();
		double distanceKM = findAllPointDTO.getDistanceKM();
		ReferencePointDTO reference = findAllPointDTO.getReferencePoint();
		List<ReferencePointDTO> references = findAllPointDTO.getArray();
		references.forEach(e -> {
			LatLongDTO latLong = LatLongDTO.builder().lat1(reference.getLatitude()).lon1(reference.getLongitude())
					.lat2(e.getLatitude()).lon2(e.getLongitude()).build();
			double distance = CommonFunctions.getDistanceFromLatLonInKm(latLong);
			if (distance <= distanceKM) {
				log.info("lie in 100KM is :"+distance);
				lieReferences.add(e);
			}
		});
		return ResultPointDTO.builder().result(lieReferences).build();
	}

	@Override
	public SortedDistanceDTO sortDistance(SortDistanceDTO sortDistanceDTO) {
		Validations.isValidSortDistanceDTO(sortDistanceDTO);
		ReferencePointDTO reference = sortDistanceDTO.getReferencePoint();
		List<ReferencePointDTO> references = sortDistanceDTO.getArray();
		TreeMap<Double, ReferencePointDTO> distanceWithLatLong = new TreeMap<Double, ReferencePointDTO>();
		references.forEach(e -> {
			LatLongDTO latLong = LatLongDTO.builder().lat1(reference.getLatitude()).lon1(reference.getLongitude())
					.lat2(e.getLatitude()).lon2(e.getLongitude()).build();
			double distance = CommonFunctions.getDistanceFromLatLonInKm(latLong);
			distanceWithLatLong.put(distance, e);
		});
		log.info("ascending order distances : " + distanceWithLatLong.keySet());
		List<ReferencePointDTO> sortedArray = new ArrayList<>(distanceWithLatLong.values());
		log.info("sorted list is :", sortedArray);
		return SortedDistanceDTO.builder().sortedArray(sortedArray).build();
	}

}
