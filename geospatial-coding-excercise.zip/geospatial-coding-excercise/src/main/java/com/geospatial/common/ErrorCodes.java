package com.geospatial.common;

public enum ErrorCodes {

	  ORDER_CREATED("1", "Order created successfully."),
	  REQUIRED_FIELD_MISSING("ERR_001", "Required field is missing."),
	  METHOD_NOT_ALLOW("ERR_002", "Method note allow."),
	  MESSAGE_NOT_READABLE("ERR_003", "Message not readable format."),
	  LATITUDE1_MISSING("ERR_004", "Latitude1 is missing.");
	 
	  

	  private final String code;
	  private final String description;

	  private ErrorCodes(String code, String description) {
	    this.code = code;
	    this.description = description;
	  }

	  public String getDescription() {
	     return description;
	  }

	  public String getCode() {
	     return code;
	  }

	  @Override
	  public String toString() {
	    return code + ": " + description;
	  }
}
