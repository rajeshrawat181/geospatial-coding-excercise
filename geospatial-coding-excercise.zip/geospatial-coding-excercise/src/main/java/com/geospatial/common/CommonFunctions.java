package com.geospatial.common;

import java.text.DecimalFormat;

import com.geospatial.model.dto.requestDTO.LatLongDTO;

public class CommonFunctions {

	public static double getDistanceFromLatLonInKm(LatLongDTO latLongDTO) {
		DecimalFormat df = new DecimalFormat("0.00");
		/*
		 * double R = 6371; double dLat =
		 * deg2rad(latLongDTO.getLat2()-latLongDTO.getLon1()); double dLon =
		 * deg2rad(latLongDTO.getLon2()-latLongDTO.getLon1()); double a =
		 * Math.sin(dLat/2)*Math.sin(dLat/2)+Math.cos(deg2rad(latLongDTO.getLat1()))*
		 * Math.cos(deg2rad(latLongDTO.getLat2())) * Math.sin(dLon/2)*Math.sin(dLon/2);
		 * double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); double d = R * c;
		 * return d;
		 */

		double theta = latLongDTO.getLon1() - latLongDTO.getLon2();
		double dist = Math.sin(deg2rad(latLongDTO.getLat1())) * Math.sin(deg2rad(latLongDTO.getLat2()))
				+ Math.cos(deg2rad(latLongDTO.getLat1())) * Math.cos(deg2rad(latLongDTO.getLat2()))
						* Math.cos(deg2rad(theta));
		dist = Math.acos(dist);
		dist = rad2deg(dist);
		dist = dist * 60 * 1.1515;
		return Double.valueOf(df.format(dist * 1.609344));
	}

	private static double rad2deg(double rad) {
		return (rad * 180.0 / Math.PI);
	}

	public static double deg2rad(double deg) {

		return deg * (Math.PI / 180);

	}

}
