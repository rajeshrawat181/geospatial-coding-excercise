package com.geospatial.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.geospatial.model.dto.requestDTO.FindAllPointDTO;
import com.geospatial.model.dto.requestDTO.LatLongDTO;
import com.geospatial.model.dto.requestDTO.SortDistanceDTO;
import com.geospatial.service.GeoSpatialService;

@RestController
public class GeoSpatialController {

	@Autowired
	GeoSpatialService geoSpatialService;

	@PostMapping("/calculate-distance")
	public ResponseEntity<?> calculateDistance(@RequestBody LatLongDTO latLong) {   
		
		return ResponseEntity.status(HttpStatus.OK).body(geoSpatialService.calculateDistance(latLong));
	}
	
	@PostMapping("/find-points")
	public ResponseEntity<?> findPoints(@RequestBody FindAllPointDTO findAllPointDTO) {
		return ResponseEntity.status(HttpStatus.OK).body(geoSpatialService.findPoints(findAllPointDTO));
	}
	
	@PostMapping("/sort-distance")
	public ResponseEntity<?> sortDistance(@RequestBody SortDistanceDTO sortDistanceDTO) {
		return ResponseEntity.status(HttpStatus.OK).body(geoSpatialService.sortDistance(sortDistanceDTO));
	}
	
}
