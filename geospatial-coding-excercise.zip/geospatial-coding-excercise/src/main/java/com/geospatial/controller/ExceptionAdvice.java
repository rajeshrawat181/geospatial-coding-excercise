package com.geospatial.controller;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.geospatial.Exception.DistanceKMMissingException;
import com.geospatial.Exception.Latitude1MissingException;
import com.geospatial.Exception.Latitude2MissingException;
import com.geospatial.Exception.Longitude1MissingException;
import com.geospatial.Exception.Longitude2MissingException;
import com.geospatial.Exception.ReferencePointMissingException;
import com.geospatial.common.ErrorCodes;
import com.geospatial.common.ErrorResponse;

import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class ExceptionAdvice {

	@ExceptionHandler(value = Latitude1MissingException.class)
	public ResponseEntity<?> exception(Latitude1MissingException e) {

		log.error("Error while validating input :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.LATITUDE1_MISSING.getCode())
						.errorMessage(ErrorCodes.LATITUDE1_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}
	@ExceptionHandler(value = Latitude2MissingException.class)
	public ResponseEntity<?> exception(Latitude2MissingException e) {

		log.error("Error while validating input :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.REQUIRED_FIELD_MISSING.getCode())
						.errorMessage(ErrorCodes.REQUIRED_FIELD_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}
	@ExceptionHandler(value = Longitude1MissingException.class)
	public ResponseEntity<?> exception(Longitude1MissingException e) {

		log.error("Error while validating input :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.REQUIRED_FIELD_MISSING.getCode())
						.errorMessage(ErrorCodes.REQUIRED_FIELD_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}
	@ExceptionHandler(value = Longitude2MissingException.class)
	public ResponseEntity<?> exception(Longitude2MissingException e) {

		log.error("Error while validating input :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.REQUIRED_FIELD_MISSING.getCode())
						.errorMessage(ErrorCodes.REQUIRED_FIELD_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}
	@ExceptionHandler(value = DistanceKMMissingException.class)
	public ResponseEntity<?> exception(DistanceKMMissingException e) {

		log.error("Error while validating input :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.REQUIRED_FIELD_MISSING.getCode())
						.errorMessage(ErrorCodes.REQUIRED_FIELD_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}
	
	@ExceptionHandler(value = ReferencePointMissingException.class)
	public ResponseEntity<?> exception(ReferencePointMissingException e) {

		log.error("Error while validating input :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.REQUIRED_FIELD_MISSING.getCode())
						.errorMessage(ErrorCodes.REQUIRED_FIELD_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}
	
    @ExceptionHandler
    ResponseEntity<?> handle(HttpRequestMethodNotSupportedException e) {
    	log.error("Method not allow :", e);
		return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.METHOD_NOT_ALLOW.getCode())
						.errorMessage(ErrorCodes.METHOD_NOT_ALLOW.getDescription()).timeStamp(LocalDateTime.now())
						.build());
    }
    @ExceptionHandler
    ResponseEntity<?> handle(HttpMessageNotReadableException e) {
    	log.error("Message not readable format :", e);
		return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.MESSAGE_NOT_READABLE.getCode())
						.errorMessage(ErrorCodes.MESSAGE_NOT_READABLE.getDescription()).timeStamp(LocalDateTime.now())
						.build());
    }
	@ExceptionHandler(value = Exception.class)
	public ResponseEntity<?> handleGenericNotFoundException(Exception e) {
		log.error("Error while processing order :", e);
		return new ResponseEntity<>("Internal server error", HttpStatus.INTERNAL_SERVER_ERROR);

	}

}
